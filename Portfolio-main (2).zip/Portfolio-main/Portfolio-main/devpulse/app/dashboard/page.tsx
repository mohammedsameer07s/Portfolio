'use client';

import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import { BarChart2, Github, TrendingUp, Clock, Flame, Zap, LayoutDashboard, LogOut, Moon, Sun, ChevronLeft, ChevronRight } from 'lucide-react';
import Link from 'next/link';

export default function Dashboard() {
  const { data: session, status } = useSession();
  const [isDark, setIsDark] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'overview' | 'repos' | 'analytics'>('overview');

  useEffect(() => {
    const saved = localStorage.getItem('devpulse-theme');
    if (saved) setIsDark(saved === 'dark');
    document.documentElement.classList.toggle('light', !isDark);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('light', !isDark);
    localStorage.setItem('devpulse-theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  const fetchStats = async () => {
    if (!session?.accessToken) return;
    setLoading(true);
    try {
      const res = await fetch('/api/github/stats', {
        headers: { Authorization: `Bearer ${session.accessToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (e) {
      console.error('Failed to fetch stats:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session) fetchStats();
  }, [session]);

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  if (!session) {
    return <div className="min-h-screen flex items-center justify-center">Redirecting...</div>;
  }

  return (
    <div className="min-h-screen">
      <nav className="side-nav" style={{ left: '24px', top: '50%', transform: 'translateY(-50%)' }}>
        <Link href="/" className="nav-logo" style={{ width: '54px', height: '54px', display: 'grid', placeItems: 'center', background: 'linear-gradient(135deg,var(--primary),var(--secondary))', borderRadius: '50%', fontFamily: 'var(--head-font)', fontSize: '15px', fontWeight: '700', color: '#fff', boxShadow: '0 8px 25px rgba(109,124,255,0.28)' }}>
          DP
        </Link>
        <div className="nav-links" style={{ display: 'flex', flexDirection: 'column', gap: '10px', width: '100%' }}>
          <Link
            href="/dashboard"
            className="nav-link"
            style={{
              width: '100%', height: '54px', display: 'flex', alignItems: 'center', justifyContent: 'center',
              gap: '12px', padding: '0 15px', borderRadius: '14px', fontSize: '13px',
              background: viewMode === 'overview' ? 'rgba(109,124,255,.12)' : 'transparent',
              color: viewMode === 'overview' ? 'var(--primary-light)' : 'var(--muted)'
            }}
          >
            <LayoutDashboard className="w-5 h-5" />
            Overview
          </Link>
          <Link
            href="/dashboard/repos"
            className="nav-link"
            style={{
              width: '100%', height: '54px', display: 'flex', alignItems: 'center', justifyContent: 'center',
              gap: '12px', padding: '0 15px', borderRadius: '14px', fontSize: '13px',
              background: viewMode === 'repos' ? 'rgba(109,124,255,.12)' : 'transparent',
              color: viewMode === 'repos' ? 'var(--primary-light)' : 'var(--muted)'
            }}
          >
            <Github className="w-5 h-5" />
            Repositories
          </Link>
          <Link
            href="/dashboard/analytics"
            className="nav-link"
            style={{
              width: '100%', height: '54px', display: 'flex', alignItems: 'center', justifyContent: 'center',
              gap: '12px', padding: '0 15px', borderRadius: '14px', fontSize: '13px',
              background: viewMode === 'analytics' ? 'rgba(109,124,255,.12)' : 'transparent',
              color: viewMode === 'analytics' ? 'var(--primary-light)' : 'var(--muted)'
            }}
          >
            <TrendingUp className="w-5 h-5" />
            Analytics
          </Link>
        </div>
        <button
          onClick={() => setIsDark(!isDark)}
          className="theme-toggle"
          style={{ width: '42px', height: '42px', display: 'grid', placeItems: 'center', border: '1px solid var(--border)', borderRadius: '50%', background: 'transparent', color: 'var(--soft)' }}
          aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
        <a
          href="/api/auth/signout"
          className="nav-github"
          style={{ width: '42px', height: '42px', display: 'grid', placeItems: 'center', border: '1px solid var(--border)', borderRadius: '50%', background: 'transparent', color: 'var(--soft)', marginTop: '28px' }}
        >
          <LogOut className="w-5 h-5" />
        </a>
      </nav>

      <main style={{ width: 'min(1180px,calc(100% - 180px))', margin: '0 auto', paddingTop: '80px', paddingBottom: '60px' }}>
        <div className="reveal" style={{ opacity: 1, transform: 'translateY(0)' }}>
          <div className="flex items-center justify-between mb-8">
            <div>
              <p className="eyebrow">GITHUB DASHBOARD</p>
              <h1 style={{ fontFamily: 'var(--head-font)', fontSize: 'clamp(38px,5vw,58px)', lineHeight: 1, letterSpacing: '-0.04em', marginTop: '5px' }}>
                {viewMode === 'overview' && 'Overview'}
                {viewMode === 'repos' && 'Repositories'}
                {viewMode === 'analytics' && 'Analytics'}
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-soft">{session.user?.name || session.user?.login}</span>
              <img src={session.user?.image} alt="" className="w-8 h-8 rounded-full" />
            </div>
          </div>

          {viewMode === 'overview' && <OverviewView stats={stats} loading={loading} />}
          {viewMode === 'repos' && <ReposView stats={stats} loading={loading} />}
          {viewMode === 'analytics' && <AnalyticsView stats={stats} loading={loading} />}
        </div>
      </main>
    </div>
  );
}

function OverviewView({ stats, loading }: { stats: any; loading: boolean }) {
  if (loading || !stats) {
    return <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 h-64" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}><div className="col-span-full text-center text-muted">Loading dashboard...</div></div>;
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-10">
        <StatCard label="Total Repos" value={stats.totalRepos} icon={<Github className="w-6 h-6" />} />
        <StatCard label="Total Commits" value={stats.totalCommits.toLocaleString()} icon={<Zap className="w-6 h-6" />} />
        <StatCard label="Stars Earned" value={stats.totalStars} icon={<TrendingUp className="w-6 h-6" />} />
        <StatCard label="Current Streak" value={`${stats.currentStreak} days`} icon={<Flame className="w-6 h-6" />} />
        <StatCard label="Longest Streak" value={`${stats.longestStreak} days`} icon={<Clock className="w-6 h-6" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
        <div className="card p-6">
          <h3 className="font-heading text-xl mb-4">Contribution Calendar (Last Year)</h3>
          <ContributionCalendar contributions={stats.contributions} />
        </div>

        <div className="card p-6">
          <h3 className="font-heading text-xl mb-4">Top Languages</h3>
          <div className="space-y-4">
            {stats.topLanguages.slice(0, 8).map((lang: any, i: number) => (
              <div key={i} className="flex items-center gap-4">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: lang.color }} />
                <span className="flex-1 text-sm font-medium">{lang.name}</span>
                <div className="flex-2 h-2 bg-surface rounded overflow-hidden">
                  <div
                    className="h-full rounded"
                    style={{
                      width: `${(lang.count / stats.topLanguages[0].count) * 100}%`,
                      background: 'linear-gradient(90deg, var(--primary), var(--secondary))',
                    }}
                  />
                </div>
                <span className="text-sm text-muted w-16 text-right">{lang.count} bytes</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card p-6">
        <h3 className="font-heading text-xl mb-4">Recent Activity</h3>
        {stats.recentActivity.length ? (
          <div className="space-y-3">
            {stats.recentActivity.slice(0, 15).map((activity: any, i: number) => (
              <div key={i} className="flex items-start gap-4 p-4 bg-surface rounded-xl border border-border">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  {activity.type === 'PushEvent' && <Github className="w-5 h-5 text-primary" />}
                  {activity.type === 'CreateEvent' && <BarChart2 className="w-5 h-5 text-secondary" />}
                  {activity.type === 'WatchEvent' && <TrendingUp className="w-5 h-5 text-amber-500" />}
                  {activity.type === 'ForkEvent' && <Zap className="w-5 h-5 text-green-500" />}
                  {activity.type === 'PullRequestEvent' && <Clock className="w-5 h-5 text-blue-500" />}
                  {activity.type === 'IssuesEvent' && <Flame className="w-5 h-5 text-red-500" />}
                  {activity.type === 'ReleaseEvent' && <TrendingUp className="w-5 h-5 text-purple-500" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{activity.type.replace('Event', '')} to <span className="text-primary">{activity.repo}</span></p>
                  <p className="text-xs text-muted mt-1">{activity.description}</p>
                </div>
                <time className="text-xs text-muted whitespace-nowrap">{new Date(activity.date).toLocaleString()}</time>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted">No recent activity</div>
        )}
      </div>
    </>
  );
}

function ReposView({ stats, loading }: { stats: any; loading: boolean }) {
  if (loading || !stats) {
    return <div className="text-center text-muted py-20">Loading repositories...</div>;
  }

  return (
    <div className="card p-6">
      <h3 className="font-heading text-xl mb-6">Your Repositories</h3>
      <div className="text-muted text-center py-10">
        Repository list view - connect GitHub API to see all repos with stats
      </div>
    </div>
  );
}

function AnalyticsView({ stats, loading }: { stats: any; loading: boolean }) {
  if (loading || !stats) {
    return <div className="text-center text-muted py-20">Loading analytics...</div>;
  }

  return (
    <div className="card p-6">
      <h3 className="font-heading text-xl mb-6">Advanced Analytics</h3>
      <div className="text-muted text-center py-10">
        Analytics view - commit patterns, productivity trends, collaboration insights
      </div>
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string; value: string | number; icon: React.ReactNode }) {
  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
          {icon}
        </div>
        <span className="text-sm font-medium text-soft">{label}</span>
      </div>
      <p className="font-heading text-3xl font-bold">{value}</p>
    </div>
  );
}

function ContributionCalendar({ contributions }: { contributions: Array<{ date: string; count: number }> }) {
  const maxCount = Math.max(...contributions.map(c => c.count), 1);
  const weeks = 52;
  const days = 7;

  return (
    <div className="font-mono text-xs">
      <div className="flex gap-1 overflow-x-auto" style={{ minWidth: `${weeks * 12}px` }}>
        {Array.from({ length: weeks }).map((_, w) => (
          <div key={w} className="flex flex-col gap-1 flex-shrink-0">
            {Array.from({ length: days }).map((_, d) => {
              const date = new Date();
              date.setDate(date.getDate() - (weeks - w) * 7 - (6 - d));
              const dateStr = date.toISOString().split('T')[0];
              const contrib = contributions.find(c => c.date === dateStr);
              const count = contrib?.count || 0;
              const intensity = count > 0 ? Math.min(Math.ceil((count / maxCount) * 4), 4) : 0;
              const colors = [
                'rgba(255,255,255,0.05)',
                'rgba(109,124,255,0.3)',
                'rgba(109,124,255,0.5)',
                'rgba(109,124,255,0.7)',
                'rgba(109,124,255,1)',
              ];
              return (
                <div
                  key={d}
                  className="w-2 h-2 rounded-sm"
                  style={{ backgroundColor: colors[intensity] }}
                  title={`${dateStr}: ${count} contributions`}
                />
              );
            })}
          </div>
        ))}
      </div>
      <div className="flex gap-1 mt-4 text-xs text-muted">
        <span className="w-20">Less</span>
        {[0, 1, 2, 3, 4].map(i => (
          <div key={i} className="w-2 h-2 rounded-sm ml-1" style={{ backgroundColor: [
            'rgba(255,255,255,0.05)',
            'rgba(109,124,255,0.3)',
            'rgba(109,124,255,0.5)',
            'rgba(109,124,255,0.7)',
            'rgba(109,124,255,1)',
          ][i] }} />
        ))}
        <span className="ml-2">More</span>
      </div>
    </div>
  );
}