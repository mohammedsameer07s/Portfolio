import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const token = authHeader.replace('Bearer ', '');

  try {
    // Fetch user info
    const userRes = await fetch('https://api.github.com/user', {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json' },
    });
    if (!userRes.ok) throw new Error('Failed to fetch user');
    const user = await userRes.json();

    // Fetch repos
    const reposRes = await fetch(`https://api.github.com/users/${user.login}/repos?per_page=100&sort=updated`, {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json' },
    });
    if (!reposRes.ok) throw new Error('Failed to fetch repos');
    const repos = await reposRes.json();

    // Fetch contributions (last year)
    const contributionsRes = await fetch(`https://github-contributions-api.jstrieb.dev/${user.login}`, {
      headers: { Accept: 'application/json' },
    });
    let contributions: Array<{ date: string; count: number }> = [];
    if (contributionsRes.ok) {
      const contribData = await contributionsRes.json();
      contributions = contribData.contributions || [];
    }

    // Calculate stats
    const totalRepos = repos.length;
    const totalStars = repos.reduce((sum: number, r: any) => sum + (r.stargazers_count || 0), 0);

    // Fetch commit counts for owned repos (sample first 10 to avoid rate limits)
    let totalCommits = 0;
    const ownedRepos = repos.filter((r: any) => !r.fork).slice(0, 10);
    for (const repo of ownedRepos) {
      try {
        const commitsRes = await fetch(`https://api.github.com/repos/${user.login}/${repo.name}/commits?author=${user.login}&per_page=1`, {
          headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json' },
        });
        if (commitsRes.ok) {
          const link = commitsRes.headers.get('Link');
          if (link) {
            const lastPageMatch = link.match(/page=(\d+)>; rel="last"/);
            if (lastPageMatch) totalCommits += parseInt(lastPageMatch[1]);
          } else {
            const commits = await commitsRes.json();
            totalCommits += commits.length;
          }
        }
      } catch {
        // Ignore individual repo errors
      }
    }

    // Calculate streaks from contributions
    const sortedContribs = contributions
      .filter(c => c.count > 0)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    let currentStreak = 0;
    let longestStreak = 0;
    let tempStreak = 0;
    let lastDate: Date | null = null;

    for (const c of contributions.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())) {
      if (c.count > 0) {
        const currDate = new Date(c.date);
        if (lastDate) {
          const diff = Math.floor((currDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
          if (diff === 1) {
            tempStreak++;
          } else if (diff > 1) {
            longestStreak = Math.max(longestStreak, tempStreak);
            tempStreak = 1;
          }
        } else {
          tempStreak = 1;
        }
        lastDate = currDate;
      }
    }
    longestStreak = Math.max(longestStreak, tempStreak);

    // Current streak (from today backwards)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const contribMap = new Map(contributions.map(c => [c.date, c.count]));
    let checkDate = new Date(today);
    if (!contribMap.has(today.toISOString().split('T')[0])) {
      checkDate.setDate(checkDate.getDate() - 1);
    }
    currentStreak = 0;
    while (contribMap.get(checkDate.toISOString().split('T')[0]) > 0) {
      currentStreak++;
      checkDate.setDate(checkDate.getDate() - 1);
    }

    // Top languages
    const langCounts: Record<string, { count: number; color: string }> = {};
    const langColors: Record<string, string> = {
      JavaScript: '#f1e05a', TypeScript: '#2b7489', Python: '#3572A5', PHP: '#4F5D95',
      Java: '#b07219', 'C++': '#f34b7d', C: '#555555', Go: '#00ADD8', Rust: '#dea584',
      HTML: '#e34c26', CSS: '#563d7c', Shell: '#89e051', Vue: '#41b883',
      Swift: '#ffac45', Kotlin: '#A97BFF', Dart: '#00B4AB', Ruby: '#701516',
    };
    for (const repo of repos) {
      if (repo.language) {
        if (!langCounts[repo.language]) langCounts[repo.language] = { count: 0, color: langColors[repo.language] || '#6d7cff' };
        langCounts[repo.language].count += repo.size || 1;
      }
    }
    const topLanguages = Object.entries(langCounts)
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 10)
      .map(([name, data]) => ({ name, count: data.count, color: data.color }));

    // Recent activity (from events API)
    const eventsRes = await fetch(`https://api.github.com/users/${user.login}/events/public?per_page=30`, {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github.v3+json' },
    });
    let recentActivity: Array<{ type: string; repo: string; date: string; description: string }> = [];
    if (eventsRes.ok) {
      const events = await eventsRes.json();
      recentActivity = events.map((e: any) => ({
        type: e.type,
        repo: e.repo?.name || '',
        date: e.created_at,
        description: getEventDescription(e),
      })).filter((a: any) => a.repo);
    }

    return NextResponse.json({
      totalRepos,
      totalCommits,
      totalStars,
      currentStreak,
      longestStreak,
      contributions,
      topLanguages,
      recentActivity,
    });
  } catch (error) {
    console.error('GitHub stats error:', error);
    return NextResponse.json({ error: 'Failed to fetch stats' }, { status: 500 });
  }
}

function getEventDescription(event: any): string {
  switch (event.type) {
    case 'PushEvent':
      const commits = event.payload?.commits?.length || 0;
      return `Pushed ${commits} commit${commits !== 1 ? 's' : ''}`;
    case 'CreateEvent':
      return `Created ${event.payload?.ref_type || 'repository'}`;
    case 'WatchEvent':
      return 'Starred repository';
    case 'ForkEvent':
      return 'Forked repository';
    case 'PullRequestEvent':
      return `${event.payload?.action || 'Updated'} pull request`;
    case 'IssuesEvent':
      return `${event.payload?.action || 'Updated'} issue`;
    case 'ReleaseEvent':
      return `Published release ${event.payload?.release?.tag_name || ''}`;
    default:
      return event.type.replace('Event', '');
  }
}