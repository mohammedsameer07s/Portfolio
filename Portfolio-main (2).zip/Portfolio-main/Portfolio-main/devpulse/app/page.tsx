'use client';

import { useSession, signIn, signOut } from 'next-auth/react';
import { Github, BarChart2, LayoutDashboard, LogOut, User, Moon, Sun } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function Home() {
  const { data: session, status } = useSession();
  const [isDark, setIsDark] = useState(true);
  const [stats, setStats] = useState<{
    totalRepos: number;
    totalCommits: number;
    totalStars: number;
    currentStreak: number;
    longestStreak: number;
    contributions: Array<{ date: string; count: number }>;
    topLanguages: Array<{ name: string; count: number; color: string }>;
    recentActivity: Array<{ type: string; repo: string; date: string; description: string }>;
  } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('devpulse-theme');
    if (saved) setIsDark(saved === 'dark');
    else if (window.matchMedia('(prefers-color-scheme: dark)').matches) setIsDark(true);
    document.documentElement.classList.toggle('light', !isDark);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('light', !isDark);
    localStorage.setItem('devpulse-theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  const fetchStats = async () => {
    if (!session?.accessToken) return;
    setLoading(true);
    try {
      const res = await fetch('/api/github/stats', {
        headers: { Authorization: `Bearer ${session.accessToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (e) {
      console.error('Failed to fetch stats:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session) fetchStats();
  }, [session]);

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  if (!session) {
    return (
      <main className="min-h-screen flex items-center justify-center p-8">
        <div className="card max-w-md w-full p-10 text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <Github className="w-10 h-10 text-white" />
          </div>
          <h1 className="font-heading text-3xl font-bold mb-2">DevPulse</h1>
          <p className="text-soft mb-8">Your GitHub activity dashboard. Visualize contributions, track streaks, and analyze coding patterns.</p>
          <button
            onClick={() => signIn('github', { callbackUrl: '/dashboard' })}
            className="btn btn-primary w-full"
          >
            <Github className="w-5 h-5" />
            Continue with GitHub
          </button>
          <p className="text-xs text-muted mt-4">No data stored. Read-only access to public profile & repos.</p>
        </div>
      </main>
    );
  }

  return (
    <div className="min-h-screen">
      <nav className="side-nav" style={{ left: '24px', top: '50%', transform: 'translateY(-50%)' }}>
        <a href="#about" className="nav-logo" style={{ width: '54px', height: '54px', display: 'grid', placeItems: 'center', background: 'linear-gradient(135deg,var(--primary),var(--secondary))', borderRadius: '50%', fontFamily: 'var(--head-font)', fontSize: '15px', fontWeight: '700', color: '#fff', boxShadow: '0 8px 25px rgba(109,124,255,0.28)' }}>
          DP
        </a>
        <div className="nav-links" style={{ display: 'flex', flexDirection: 'column', gap: '10px', width: '100%' }}>
          <a href="/dashboard" className="nav-link" style={{ width: '100%', height: '54px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', padding: '0 15px', borderRadius: '14px', fontSize: '13px', background: 'rgba(109,124,255,.12)', color: 'var(--primary-light)' }}>
            <LayoutDashboard className="w-5 h-5" />
            Dashboard
          </a>
        </div>
        <button
          onClick={() => setIsDark(!isDark)}
          className="theme-toggle"
          style={{ width: '42px', height: '42px', display: 'grid', placeItems: 'center', border: '1px solid var(--border)', borderRadius: '50%', background: 'transparent', color: 'var(--soft)' }}
          aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
        <button
          onClick={() => signOut({ callbackUrl: '/' })}
          className="nav-github"
          style={{ width: '42px', height: '42px', display: 'grid', placeItems: 'center', border: '1px solid var(--border)', borderRadius: '50%', background: 'transparent', color: 'var(--soft)', marginTop: '28px' }}
        >
          <LogOut className="w-5 h-5" />
        </button>
      </nav>

      <main style={{ width: 'min(1180px,calc(100% - 180px))', margin: '0 auto', paddingTop: '80px' }}>
        <div className="reveal" style={{ opacity: 1, transform: 'translateY(0)' }}>
          <p className="eyebrow">GITHUB DASHBOARD</p>
          <h1 style={{ fontFamily: 'var(--head-font)', fontSize: 'clamp(48px,6vw,76px)', lineHeight: 1.02, letterSpacing: '-0.055em', marginTop: '18px' }}>
            Welcome back, <span style={{ display: 'block', color: 'var(--primary-light)' }}>{session.user?.name || session.user?.login}</span>
          </h1>
          <p className="hero-description" style={{ marginTop: '24px', maxWidth: '570px' }}>
            Track your coding activity, visualize contribution patterns, and explore your repositories.
          </p>

          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mt-10">
              <StatCard label="Total Repos" value={stats.totalRepos} icon={<Github className="w-6 h-6" />} />
              <StatCard label="Total Commits" value={stats.totalCommits.toLocaleString()} icon={<BarChart2 className="w-6 h-6" />} />
              <StatCard label="Stars Earned" value={stats.totalStars} icon={<BarChart2 className="w-6 h-6" />} />
              <StatCard label="Current Streak" value={`${stats.currentStreak} days`} icon={<BarChart2 className="w-6 h-6" />} />
              <StatCard label="Longest Streak" value={`${stats.longestStreak} days`} icon={<BarChart2 className="w-6 h-6" />} />
            </div>
          )}

          <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card p-6 reveal" style={{ opacity: 1, transform: 'translateY(0)' }}>
              <h3 className="font-heading text-xl mb-4">Contribution Calendar</h3>
              {loading ? (
                <div className="h-64 flex items-center justify-center text-muted">Loading...</div>
              ) : stats ? (
                <ContributionCalendar contributions={stats.contributions} />
              ) : (
                <div className="h-64 flex items-center justify-center text-muted">Connect GitHub to see data</div>
              )}
            </div>

            <div className="card p-6 reveal" style={{ opacity: 1, transform: 'translateY(0)' }}>
              <h3 className="font-heading text-xl mb-4">Top Languages</h3>
              {stats?.topLanguages.length ? (
                <div className="space-y-4">
                  {stats.topLanguages.slice(0, 8).map((lang, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: lang.color }} />
                      <span className="flex-1 text-sm font-medium">{lang.name}</span>
                      <div className="flex-2 h-2 bg-surface rounded overflow-hidden">
                        <div
                          className="h-full rounded"
                          style={{
                            width: `${(lang.count / stats.topLanguages[0].count) * 100}%`,
                            background: `linear-gradient(90deg, var(--primary), var(--secondary))`,
                          }}
                        />
                      </div>
                      <span className="text-sm text-muted w-16 text-right">{lang.count}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-muted">No language data</div>
              )}
            </div>
          </div>

          <div className="mt-10 reveal" style={{ opacity: 1, transform: 'translateY(0)' }}>
            <div className="card p-6">
              <h3 className="font-heading text-xl mb-4">Recent Activity</h3>
              {stats?.recentActivity.length ? (
                <div className="space-y-3">
                  {stats.recentActivity.slice(0, 10).map((activity, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-4 p-4 bg-surface rounded-xl border border-border"
                    >
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        {activity.type === 'PushEvent' && <Github className="w-5 h-5 text-primary" />}
                        {activity.type === 'CreateEvent' && <BarChart2 className="w-5 h-5 text-secondary" />}
                        {activity.type === 'WatchEvent' && <BarChart2 className="w-5 h-5 text-amber-500" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm">{activity.type.replace('Event', '')} to <span className="text-primary">{activity.repo}</span></p>
                        <p className="text-xs text-muted mt-1">{activity.description}</p>
                      </div>
                      <time className="text-xs text-muted whitespace-nowrap">{new Date(activity.date).toLocaleDateString()}</time>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted">No recent activity</div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string; value: string | number; icon: React.ReactNode }) {
  return (
    <div className="card p-6 reveal" style={{ opacity: 1, transform: 'translateY(0)' }}>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
          {icon}
        </div>
        <span className="text-sm font-medium text-soft">{label}</span>
      </div>
      <p className="font-heading text-3xl font-bold">{value}</p>
    </div>
  );
}

function ContributionCalendar({ contributions }: { contributions: Array<{ date: string; count: number }> }) {
  const maxCount = Math.max(...contributions.map(c => c.count), 1);
  const weeks = 52;
  const days = 7;

  return (
    <div className="font-mono text-xs">
      <div className="flex gap-1" style={{ minWidth: `${weeks * 12}px` }}>
        {Array.from({ length: weeks }).map((_, w) => (
          <div key={w} className="flex flex-col gap-1">
            {Array.from({ length: days }).map((_, d) => {
              const date = new Date();
              date.setDate(date.getDate() - (weeks - w) * 7 - (6 - d));
              const dateStr = date.toISOString().split('T')[0];
              const contrib = contributions.find(c => c.date === dateStr);
              const count = contrib?.count || 0;
              const intensity = count > 0 ? Math.min(Math.ceil((count / maxCount) * 4), 4) : 0;
              const colors = [
                'rgba(255,255,255,0.05)',
                'rgba(109,124,255,0.3)',
                'rgba(109,124,255,0.5)',
                'rgba(109,124,255,0.7)',
                'rgba(109,124,255,1)',
              ];
              return (
                <div
                  key={d}
                  className="w-2 h-2 rounded-sm"
                  style={{ backgroundColor: colors[intensity] }}
                  title={`${dateStr}: ${count} contributions`}
                />
              );
            })}
          </div>
        ))}
      </div>
      <div className="flex gap-1 mt-4 text-xs text-muted">
        <span className="w-20">Less</span>
        {[0, 1, 2, 3, 4].map(i => (
          <div key={i} className="w-2 h-2 rounded-sm ml-1" style={{ backgroundColor: [
            'rgba(255,255,255,0.05)',
            'rgba(109,124,255,0.3)',
            'rgba(109,124,255,0.5)',
            'rgba(109,124,255,0.7)',
            'rgba(109,124,255,1)',
          ][i] }} />
        ))}
        <span className="ml-2">More</span>
      </div>
    </div>
  );
}