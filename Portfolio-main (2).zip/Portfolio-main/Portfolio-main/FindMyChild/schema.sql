-- Find My Child Database Schema (PostgreSQL for Render)
-- Run on first deploy: psql $DATABASE_URL -f schema.sql

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis"; -- For geospatial queries

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('user', 'authority', 'admin')),
    avatar_url TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Missing child reports
CREATE TABLE missing_children (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reporter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    full_name VARCHAR(255) NOT NULL,
    date_of_birth DATE,
    age_at_disappearance INTEGER,
    gender VARCHAR(20),
    height_cm INTEGER,
    weight_kg INTEGER,
    hair_color VARCHAR(50),
    eye_color VARCHAR(50),
    distinguishing_marks TEXT,
    last_seen_location VARCHAR(500),
    last_seen_latitude DECIMAL(10,8),
    last_seen_longitude DECIMAL(11,8),
    last_seen_at TIMESTAMP WITH TIME ZONE NOT NULL,
    clothing_description TEXT,
    circumstances TEXT,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'found', 'closed')),
    case_number VARCHAR(50) UNIQUE,
    police_report_number VARCHAR(100),
    police_station VARCHAR(255),
    contact_info JSONB, -- {phone, email, preferred_contact}
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_missing_children_reporter ON missing_children(reporter_id);
CREATE INDEX idx_missing_children_status ON missing_children(status);
CREATE INDEX idx_missing_children_location ON missing_children(last_seen_latitude, last_seen_longitude);
CREATE INDEX idx_missing_children_last_seen ON missing_children(last_seen_at);
CREATE INDEX idx_missing_children_case ON missing_children(case_number);

-- Child images
CREATE TABLE child_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    child_id UUID NOT NULL REFERENCES missing_children(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    description VARCHAR(255),
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_child_images_child ON child_images(child_id);

-- Sightings / tips
CREATE TABLE sightings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    child_id UUID NOT NULL REFERENCES missing_children(id) ON DELETE CASCADE,
    reporter_id UUID REFERENCES users(id) ON DELETE SET NULL,
    reporter_name VARCHAR(255),
    reporter_phone VARCHAR(20),
    reporter_email VARCHAR(255),
    location VARCHAR(500),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    sighted_at TIMESTAMP WITH TIME ZONE NOT NULL,
    description TEXT,
    confidence_level VARCHAR(20) DEFAULT 'medium' CHECK (confidence_level IN ('low', 'medium', 'high')),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'verified', 'rejected')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sightings_child ON sightings(child_id);
CREATE INDEX idx_sightings_location ON sightings(latitude, longitude);
CREATE INDEX idx_sightings_sighted_at ON sightings(sighted_at);
CREATE INDEX idx_sightings_status ON sightings(status);

-- Alerts / notifications sent
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    child_id UUID NOT NULL REFERENCES missing_children(id) ON DELETE CASCADE,
    alert_type VARCHAR(30) NOT NULL CHECK (alert_type IN ('email', 'sms', 'push', 'social')),
    recipient_count INTEGER DEFAULT 0,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);

CREATE INDEX idx_alerts_child ON alerts(child_id);

-- User subscriptions for alerts
CREATE TABLE alert_subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    radius_km INTEGER DEFAULT 50,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    alert_types TEXT[] DEFAULT ARRAY['email'],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_subscriptions_user ON alert_subscriptions(user_id);
CREATE INDEX idx_subscriptions_location ON alert_subscriptions(latitude, longitude);

-- Resources / safety tips
CREATE TABLE resources (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(50),
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Updated timestamp trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_missing_children_updated_at BEFORE UPDATE ON missing_children FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_resources_updated_at BEFORE UPDATE ON resources FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();