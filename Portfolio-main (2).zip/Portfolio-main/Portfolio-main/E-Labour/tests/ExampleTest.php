<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

final class ExampleTest extends TestCase
{
    public function testTrueIsTrue(): void
    {
        $this->assertTrue(true);
    }

    public function testStringContains(): void
    {
        $this->assertStringContainsString('E-Labour', 'E-Labour Platform');
    }
}