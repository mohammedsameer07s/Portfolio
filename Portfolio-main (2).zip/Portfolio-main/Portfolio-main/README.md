# Mohammed Sameer — Software Developer Portfolio

A modern, responsive portfolio website showcasing full-stack web development projects with live demos, technical depth, and a working contact form.

## Features

- **Dark/Light theme** with persistence
- **Responsive design** (mobile-first, breakpoints at 500px, 800px, 1050px)
- **Smooth scroll navigation** with active section highlighting
- **Intersection Observer animations** for scroll reveals
- **AI Chatbot** (Netlify Functions + Groq API)
- **Contact form** (Netlify Forms with honeypot spam protection)
- **WhatsApp float button** for direct messaging
- **Live project demos** deployed on Render
- **Skills proficiency bars** mapped to projects
- **STAR-format experience section** with quantified achievements

## Tech Stack

### Portfolio (Static Site)
- HTML5, CSS3 (custom properties, Grid, Flexbox)
- Vanilla JavaScript (ES6+)
- Font Awesome 6 icons
- Google Fonts (Inter, Space Grotesk)
- Netlify (hosting, functions, forms)
- Netlify Functions (serverless chatbot)

### Projects (PHP 8.2 + PostgreSQL)
- **E-Labour** — Service marketplace with geo-search, Redis caching
- **Find My Child** — Missing child alerts with PostGIS geospatial queries
- **ExpenseFlow** — Finance tracker with materialized views, Chart.js
- All deployed on **Render** with managed PostgreSQL

### DevPulse (Next.js 14 + TypeScript)
- GitHub OAuth (NextAuth.js)
- GitHub API integration (repos, commits, contributions)
- Recharts visualization
- Tailwind CSS
- Deployed on **Vercel**

### CI/CD
- **GitHub Actions** for all projects
- PHP: PHPUnit, PHPCS (PSR-12), PHPStan
- Next.js: ESLint, TypeScript, Build verification
- Auto-deploy to Render (PHP) and Vercel (Next.js)

## Quick Start

### Portfolio (Local Development)
```bash
# Install dependencies
npm install

# Start dev server
npm run dev
# Opens http://localhost:8888
```

### DevPulse (Next.js App)
```bash
cd devpulse
npm install
npm run dev
# Opens http://localhost:3000
```

### Environment Variables

#### Portfolio (Netlify)
Set in Netlify Dashboard → Site Settings → Environment Variables:
```
GROQ_API_KEY=your_groq_api_key
```

#### DevPulse (Vercel)
Set in Vercel Dashboard → Project Settings → Environment Variables:
```
GITHUB_CLIENT_ID=your_github_oauth_client_id
GITHUB_CLIENT_SECRET=your_github_oauth_client_secret
NEXTAUTH_SECRET=generate_with_openssl_rand_base64_32
NEXTAUTH_URL=https://your-vercel-domain.vercel.app
```

#### GitHub Actions (Repository Secrets)
Go to Settings → Secrets and variables → Actions:
```
RENDER_DEPLOY_HOOK_E_LABOUR=https://api.render.com/deploy/xxx
RENDER_DEPLOY_HOOK_FMC=https://api.render.com/deploy/xxx
RENDER_DEPLOY_HOOK_EF=https://api.render.com/deploy/xxx
VERCEL_TOKEN=your_vercel_token
VERCEL_ORG_ID=your_vercel_org_id
VERCEL_PROJECT_ID=your_vercel_project_id
```

## Deployment

### Portfolio → Netlify
1. Connect GitHub repo to Netlify
2. Build command: (none — static site)
3. Publish directory: `.` (root)
4. Functions directory: `netlify/functions`
5. Add environment variables
6. Enable Netlify Forms in dashboard

### PHP Projects → Render
1. Create new **Web Service** in Render
2. Connect GitHub repo (subdirectory: `E-Labour`, `FindMyChild`, or `ExpenseFlow`)
3. Runtime: PHP 8.2
4. Build command: `composer install --no-dev --optimize-autoloader`
5. Start command: `php -S 0.0.0.0:$PORT -t public`
6. Add **PostgreSQL Database** (free tier)
7. Link database env vars in service settings
8. Run schema: `psql $DATABASE_URL -f schema.sql`

### DevPulse → Vercel
1. Import GitHub repo in Vercel
2. Root directory: `devpulse`
3. Framework preset: Next.js
4. Add environment variables
5. Deploy

## Project Structure

```
Portfolio-main/
├── index.html              # Main portfolio page
├── style.css               # All styles (CSS custom properties)
├── script.js               # Vanilla JS (navigation, theme, chatbot, forms)
├── netlify.toml            # Netlify config (headers, redirects, functions)
├── package.json            # Root scripts (lint, format, dev)
├── .prettierrc             # Prettier config
├── .gitignore
├── README.md
├── profile.jpeg
├── resume.pdf
├── robots.txt
├── sitemap.xml
├── netlify/
│   └── functions/
│       └── portfolio-chat.js    # Groq-powered chatbot
├── .github/
│   └── workflows/
│       └── ci.yml               # GitHub Actions CI/CD
├── E-Labour/                 # PHP project 1
│   ├── render.yaml           # Render service + DB config
│   ├── composer.json         # PHP dependencies
│   ├── schema.sql            # PostgreSQL schema
│   ├── phpunit.xml.dist      # PHPUnit config
│   └── tests/
├── FindMyChild/              # PHP project 2
│   ├── render.yaml
│   ├── composer.json
│   ├── schema.sql
│   ├── phpunit.xml.dist
│   └── tests/
├── ExpenseFlow/              # PHP project 3
│   ├── render.yaml
│   ├── composer.json
│   ├── schema.sql
│   ├── phpunit.xml.dist
│   └── tests/
└── devpulse/                 # Next.js 14 project
    ├── package.json
    ├── tsconfig.json
    ├── next.config.js
    ├── tailwind.config.js
    ├── postcss.config.js
    ├── middleware.ts
    └── app/
        ├── globals.css
        ├── layout.tsx
        ├── providers.tsx
        ├── page.tsx                 # Landing + dashboard
        ├── dashboard/page.tsx       # Protected dashboard
        └── api/
            ├── auth/[...nextauth]/  # NextAuth GitHub OAuth
            └── github/stats/        # GitHub stats proxy
```

## Commands

```bash
# Portfolio
npm run dev          # Start dev server (port 8888)
npm run build        # No-op (static site)
npm run format       # Prettier format all files
npm run lint:html    # HTMLHint
npm run lint:css     # Stylelint
npm run lint:js      # ESLint

# DevPulse
npm run devpulse:dev   # Next.js dev server
npm run devpulse:build # Production build
npm run devpulse:lint  # ESLint + TypeScript check
```

## Performance

- **Lighthouse scores**: 95+ across all categories
- **CSS/JS**: Inlined critical CSS, deferred non-critical
- **Images**: WebP recommended (profile.jpeg ~272KB → optimize to <100KB)
- **Fonts**: `font-display: swap`, preconnect hints
- **Caching**: Netlify headers for static assets (1 year)

## Accessibility

- Semantic HTML5 landmarks
- Skip link for keyboard navigation
- ARIA labels on interactive elements
- Focus-visible outlines
- Reduced motion support
- Color contrast (WCAG AA)
- Live regions for chatbot

## License

MIT © Mohammed Sameer